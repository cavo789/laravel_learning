<?php

namespace App\Repositories;

use App\Todo;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Requests\TodoRequest;

/**
 * Define the function that should be available through the
 * TodoRepository
 */
interface TodoRepositoryInterface
{
	/**
	 * Get the list of records of the table
	 *
	 * @return Collection
	 */
	public function index() : Collection;

	/**
	 * Get a specific todo; identified by his ID
	 *
	 * @param  integer $id
	 * @return Todo
	 */
	public function get(int $id) : Todo;

	/**
	 * Save the todo
	 *
	 * @param  TodoRequest $todo Submitted data
	 * @return void
	 */
	public function save(TodoRequest $todo);

	/**
	 * Remove the specified todo
	 *
	 * @param  integer $id
	 * @return void
	 */
	public function delete(int $id);

	/**
	 * Update the specified todo, update columns
	 *
	 * @param  TodoRequest $request
	 * @return void
	 */
	public function put(TodoRequest $request);
}
