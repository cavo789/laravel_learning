<?php

namespace App\Repositories;

use App\Http\Requests\TodoRequest;
use Illuminate\Database\Eloquent\Collection;
use App\Todo;
use Auth;

/**
 * Implements functions for working with the todos table
 */
class TodoRepository implements TodoRepositoryInterface
{
	protected $todo;

	public function __construct(Todo $todo)
	{
		$this->todo = $todo;
	}

	/**
	 * Get the list of records of the table
	 *
	 * @return Collection
	 */
	public function index() : Collection
	{
		return $this->todo->all();
	}

	/**
	 * Get a specific todo; identified by his ID
	 *
	 * @param  integer $id
	 * @return Todo
	 */
	public function get(int $id) : Todo
	{
		return $this->todo->where('id', $id)->firstOrFail();
	}

	/**
	 * Save the todo
	 *
	 * @param  TodoRequest $todo Submitted data
	 * @return void
	 */
	public function save(TodoRequest $todo)
	{
		$this->todo->title = $todo->input('title');
		$this->todo->description = $todo->input('description');
		$this->todo->completed = false;
		$this->todo->user_id = Auth::user()->id;

		$this->todo->save(); // Save the submitted data
	}

	/**
	 * Remove the specified todo
	 *
	 * @param  integer $id
	 * @return void
	 */
	public function delete(int $id)
	{
		$this->todo->destroy($id);
	}

	/**
	 * Update the specified todo, update columns
	 *
	 * @param  TodoRequest $request
	 * @return void
	 */
	public function put(TodoRequest $request)
	{
		// Retrieve the record
		$data = self::get($request->input('id'));

		// List of fields that we'll update
		$data->update($request->only(['title', 'completed', 'description']));
	}
}
