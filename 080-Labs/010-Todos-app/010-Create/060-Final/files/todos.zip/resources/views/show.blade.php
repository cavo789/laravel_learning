@extends('master')

@section('content')

  {{-- 
    Display the detail of a todo; make sure we've one
  --}}
  @isset($data)
    {{-- 
      Show informations like title, description and timestamps
    --}}
    <h3>{{ $data->title }}</h3>
    <p>{{ $data->description }}</p>
    <small>
      Created at: {{ $data->created_at }}
      <br/>
      Last updated: {{ $data->updated_at }}
      <br/>

      {{--
        $data->user isn't a column but, in our model, the user() function
        returns an object which represent a record of the users table.
        So, through $data->user we can access to the user's name, email, ...
      --}}
      Author: {{ $data->user->name }}
    </small>

    {{--
      Only for logged-in users, show action's buttons
      --}}
    @if(Illuminate\Support\Facades\Auth::check())      
      <hr/>
      <span class="buttons">
        <input type="button" value="Update" class="edit"/> - 
        <input type="button" value="Delete" class="delete"/>
      </span>
    @endif
    
  @endisset

@endsection

@section('navigation')
  <a href="/todo" >Add new item</a> - <a href="/">Show all</a>
@endsection

@section('script')
{{--
  Add our script for our buttons
--}}
<script defer="defer">
  $('.delete, .edit').click(function(){

    if (this.value.toUpperCase() === 'DELETE') {
      // Add the csrf-token protection but only when the request is 
      // made on the same site (no cross-domain). 
      // Don't share the token outside
      $.ajaxSetup({
        beforeSend: function(xhr, type) {
          if (!type.crossDomain) {
              xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
          }
        }
      });

      // By clicking on the delete button, make an Ajax request
      $.ajax({
        url: '/todo/{{ $data->id }}',
        type: 'DELETE',
        contentType: 'application/json',
        success: function (data) {
          if (data.hasOwnProperty("message")) {
            // Replace buttons and display the feedback message
            // Indeed, when deleted, we can't anymore edit or delete
            $('.buttons').html(data.message);
          }
        },
        error: function (data, textStatus, errorThrown) {
          console.log(data);
        }
      });
    } else {
      // The user has clicked on the edit button, redirect the browser
      // to the edit page
      window.location.replace('/todo/{{ $data->id }}/edit');
    }
});
</script>
@endsection
