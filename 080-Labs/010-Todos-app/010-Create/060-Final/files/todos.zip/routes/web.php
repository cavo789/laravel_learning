<?php

// Enable authentication routes
Auth::routes();

// Register http://127.0.0.1:8000/login and display the login screen
Route::get('home', 'HomeController@index')->name('home');

// Register the http://127.0.0.1:8000/logout and logout
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout')->middleware('auth');

// -------------------

// GET {URL} - Default URL : Show the list of todos, as a blog
Route::get('/', [
	'uses' => 'TodoController@index',
	'as' => 'showTodos'
]);

// GET {URL}/todo/{id} -> show the todo #{id}
Route::get('todo/{id}', 'TodoController@show')->where('id', '[0-9]+');

// GET {URL}/todo -> show a form -> only for logged in users
Route::get('todo', 'TodoController@getForm')->middleware('auth');

// POST {URL}/todo -> the form is being submitted -> only for logged in users
Route::post('todo', [
	'uses' => 'TodoController@postForm',
	'as' => 'storeTodo'
])->middleware('auth');

// GET {URL}/todo/{id}/edit -> edit an existing item in a form -> only for logged in users
Route::get('todo/{id}/edit', 'TodoController@edit')->where('id', '[0-9]+')->middleware('auth');

// DELETE {URL}/todo/{id} -> delete an existing item -> only for logged in users
Route::delete('todo/{id}', 'TodoController@delete')->where('id', '[0-9]+')->middleware('auth');

// PUT {URL}/todo -> update an existing item -> only for logged in users
Route::put('todo', 'TodoController@put')->middleware('auth');
